# Development App Plan Idea for Agronomus GPT

This is a planning note, not a built or tested product.
The current preview contains 9 instruction files for this family.
The comparison is based on available document text; audit the full Drive
library before selecting a definitive version.

## Observed prompt capabilities

- Document export: present in 9/9 variants.
- Web research: present in 9/9 variants.
- Interactive flow: present in 7/9 variants.
- Image generation: present in 7/9 variants.

## Standalone app direction

- Turn the best-reviewed instruction variant into an editable workflow
  with inputs, status, saved drafts, and a final quality check.
- Keep model/API credentials server-side. Confirm any external action.
- Compare outputs from representative versions using the same test cases
  before claiming one is better; document observed quality and cost.
- Preserve a human review step and do not promise instant output.
