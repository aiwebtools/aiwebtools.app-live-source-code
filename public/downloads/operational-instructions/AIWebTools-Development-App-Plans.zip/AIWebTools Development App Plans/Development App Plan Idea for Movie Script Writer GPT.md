# Development App Plan Idea for Movie Script Writer GPT

This is a planning note, not a built or tested product.
The current preview contains 11 instruction files for this family.
The comparison is based on available document text; audit the full Drive
library before selecting a definitive version.

## Observed prompt capabilities

- Document export: present in 11/11 variants.
- Compilation: present in 11/11 variants.
- Image generation: present in 1/11 variants.
- Web research: present in 1/11 variants.

## Standalone app direction

- Turn the best-reviewed instruction variant into an editable workflow
  with inputs, status, saved drafts, and a final quality check.
- Keep model/API credentials server-side. Confirm any external action.
- Compare outputs from representative versions using the same test cases
  before claiming one is better; document observed quality and cost.
- Preserve a human review step and do not promise instant output.
