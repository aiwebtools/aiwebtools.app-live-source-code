# Development App Plan Idea for Stellaris Space Explorer

This is a planning note, not a built or tested product.
The current preview contains 20 instruction files for this family.
The comparison is based on available document text; audit the full Drive
library before selecting a definitive version.

## Observed prompt capabilities

- Document export: present in 20/20 variants.
- Web research: present in 17/20 variants.
- Compilation: present in 13/20 variants.

## Standalone app direction

- Turn the best-reviewed instruction variant into an editable workflow
  with inputs, status, saved drafts, and a final quality check.
- Keep model/API credentials server-side. Confirm any external action.
- Compare outputs from representative versions using the same test cases
  before claiming one is better; document observed quality and cost.
- Preserve a human review step and do not promise instant output.
