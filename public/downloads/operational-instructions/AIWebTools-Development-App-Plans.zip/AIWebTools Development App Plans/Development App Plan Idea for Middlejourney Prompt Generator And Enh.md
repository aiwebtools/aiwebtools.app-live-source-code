# Development App Plan Idea for Middlejourney Prompt Generator And Enhancer

This is a planning note, not a built or tested product.
The current preview contains 2 instruction files for this family.
The comparison is based on available document text; audit the full Drive
library before selecting a definitive version.

## Observed prompt capabilities

- Interactive flow: present in 2/2 variants.
- Image generation: present in 2/2 variants.
- Document export: present in 2/2 variants.
- Web research: present in 2/2 variants.

## Standalone app direction

- Turn the best-reviewed instruction variant into an editable workflow
  with inputs, status, saved drafts, and a final quality check.
- Keep model/API credentials server-side. Confirm any external action.
- Compare outputs from representative versions using the same test cases
  before claiming one is better; document observed quality and cost.
- Preserve a human review step and do not promise instant output.
