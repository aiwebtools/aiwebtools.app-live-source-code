AIWebTools.ai — Operational Instructions Library
=================================================
Original custom GPT, Gemini Gem and AI assistant operational instructions
authored by AIWebTools.ai. Every document is preserved exactly as written.
Different versions of the same assistant are kept side by side (marked
"version 2", "version 3"...). Only byte-for-byte identical copies were removed.

This archive covers file names: St to Ti
Full library: 2969 files across 9 archives.
Latest copy & source code: https://aiwebtools.ai

Use AI for good. Free and open source — share the light.
